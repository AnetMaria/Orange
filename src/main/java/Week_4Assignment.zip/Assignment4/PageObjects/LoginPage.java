package Assignment4.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
    @FindBy(xpath = "/html/body/div//p[1]")
    private WebElement lbl_user;

    @FindBy(xpath = "/html/body/div//p[2]")
    private WebElement lbl_pass;


    @FindBy(name = "username")
    private WebElement txt_userName;

    @FindBy(name = "password")
    private WebElement txt_passWord;

    @FindBy(xpath = "//button")
    private WebElement btn_login;

    @FindBy(xpath = "//div[@role='alert']//div[1]//p")
    private WebElement lbl_errorMsg;

    public void getValidCredentials()
    {
        lbl_user.getText();
        lbl_pass.getText();
    }

    public void enterUserCredentials(String userName,String password){
        txt_userName.sendKeys(userName);
        txt_passWord.sendKeys(password);
        btn_login.submit();
    }
    public boolean isInvalidErrorMsgDisplayed(){
        return lbl_errorMsg.isDisplayed();
    }
}
