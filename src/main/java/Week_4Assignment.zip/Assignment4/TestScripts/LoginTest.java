package Assignment4.TestScripts;

import Assignment3.GenericExcel;
import Assignment4.Common.GenericBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class LoginTest extends GenericBase {

    @Test(priority = 1)
    public void validateInvalidLogin(){
        driver.findElement(By.name("username")).sendKeys("newuser101");
        driver.findElement(By.name("password")).sendKeys("newuserpass101");
        driver.findElement(By.xpath("//button")).submit();

        if(driver.findElement(By.xpath("//div[@role='alert']//div[1]//p")).isDisplayed()){
            System.out.println("Passed");
        }else{
            System.out.println("Failed");
        }driver.close();
    }
    @Test(priority = 2)
    public void validateValidLogin(){
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.xpath("//button")).submit();

        if(driver.findElement(By.xpath("//div[@id='app']//h6")).isDisplayed()){
            System.out.println("Passed");
        }else{
            System.out.println("Failed");
        }
    }
}
