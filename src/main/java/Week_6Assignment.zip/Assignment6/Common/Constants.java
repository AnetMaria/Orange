package Assignment6.Common;

public class Constants {
    public static final String CURRENT_ENVIRONMENT="env";
    public static final String REPORT_PATH=System.getProperty("user.dir") + "\\Reports";
}
